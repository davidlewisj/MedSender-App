#!/usr/bin/env bash

set -euo pipefail

OUT_PATH="${1:-/tmp/medsender-sample.pdf}"

mkdir -p "$(dirname "$OUT_PATH")"

# Minimal valid PDF content (single page with one text line).
cat > "$OUT_PATH" <<'PDFEOF'
%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Count 1 /Kids [3 0 R] >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>
endobj
4 0 obj
<< /Length 57 >>
stream
BT
/F1 24 Tf
72 720 Td
(Medsender API Test Fax) Tj
ET
endstream
endobj
5 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>
endobj
xref
0 6
0000000000 65535 f 
0000000009 00000 n 
0000000058 00000 n 
0000000115 00000 n 
0000000241 00000 n 
0000000348 00000 n 
trailer
<< /Size 6 /Root 1 0 R >>
startxref
418
%%EOF
PDFEOF

echo "Generated sample PDF: $OUT_PATH"
